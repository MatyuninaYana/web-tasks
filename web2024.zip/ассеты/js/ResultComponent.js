/**
 * Создает компонент для отображения сообщения об ошибке.
 *
 * Этот компонент информирует пользователя о том, что произошла ошибка
 * при отправке заявки. Содержит кнопку для повторной попытки отправки.
 *
 * @param {Object} state Объект состояния компонента.
 * @param {Function} state.onClick Функция, вызываемая при нажатии на кнопку.
 * @returns {HTMLDivElement} Элемент `div`, содержащий сообщение об ошибке.
 */
function ErrorResultComponent(state) {
  const container = document.createElement("div");
  const img = document.createElement("img");
  const errorText = document.createElement("span");
  const button = document.createElement("button");

  container.append(img, errorText, button);

  container.style.display = "flex";
  container.style.flexDirection = "column";
  container.style.alignItems = "center";
  container.style.gap = "10px";
  container.dataset.test = "error-result-component";

  img.src = "assets/icons/status-image-error.svg";
  img.width = 120;
  img.height = 120;

  errorText.textContent =
    "Что-то пошло не так. Попробуйте отправить заявку снова";

  button.style.marginTop = "30px";
  button.textContent = "Оставить заявку снова";
  button.addEventListener("click", state.onClick);

  return container;
}

/**
 * Создает компонент для отображения сообщения об успешной отправке заявки.
 *
 * Этот компонент уведомляет пользователя о том, что заявка была успешно
 * отправлена. Содержит информацию о направлении и кнопку для отправки новой заявки.
 *
 * @param {Object} state Объект состояния компонента.
 * @param {string} state.from Место отправления заявки.
 * @param {string} state.where Место назначения заявки.
 * @param {Function} state.onClick Функция, вызываемая при нажатии на кнопку.
 * @returns {HTMLDivElement} Элемент `div`, содержащий сообщение об успешной отправке.
 */
function SuccessResultComponent(state) {
  const container = document.createElement("div");
  const img = document.createElement("img");
  const directionText = document.createElement("span");
  const successText = document.createElement("span");
  const descriptionText = document.createElement("span");
  const button = document.createElement("button");

  container.append(img, directionText, successText, descriptionText, button);

  container.style.display = "flex";
  container.style.flexDirection = "column";
  container.style.alignItems = "center";
  container.style.gap = "10px";
  container.dataset.test = "success-result-component";

  img.src = "assets/icons/status-image-success.svg";
  img.width = 120;
  img.height = 120;

  directionText.textContent = `${state.from} — ${state.where}`;
  directionText.dataset.test = "direction-result-component";

  successText.textContent = "Заявка успешно отправлена!";

  descriptionText.textContent =
    "Ожидайте обратного звонка от оператора для подтверждения заказа";

  button.style.marginTop = "30px";
  button.textContent = "Оставить ещё одну заявку";
  button.addEventListener("click", state.onClick);

  return container;
}

/**
 * Определяет, какой компонент результата отображать в зависимости от статуса заявки.
 *
 * Если статус равен "error", возвращает компонент с сообщением об ошибке.
 * Если статус равен "success", возвращает компонент с сообщением об успешной отправке.
 * Если статус не соответствует ни одному из значений, возвращает `null`.
 *
 * @param {Object} state Объект состояния компонента.
 * @param {string} state.status Статус заявки ("error", "success" или "hidden").
 * @returns {HTMLDivElement|null} Элемент результата или `null`, если статус не определен.
 */
function ResultComponent(state) {
  if (state.status === "error") return ErrorResultComponent(state);
  if (state.status === "success") return SuccessResultComponent(state);
  if (state.status === "hidden") return "";
  return null;
}
